from playwright.sync_api import expect

from pages.base_page import BasePage


class AccountPage(BasePage):
    def open_my_account(self):
        account_link = self.page.get_by_text(
            "View My Account",
            exact=True
        )
        expect(account_link).to_be_visible(timeout=15000)
        account_link.click()

    def verify_trip_is_added(self, trip_name):
        expect(
            self.page.get_by_text(trip_name, exact=False)
        ).to_be_visible(timeout=20000)

    def log_out(self):
        logout_control = self.page.get_by_role(
            "button",
            name="Log out",
            exact=True
        )
        if not logout_control.is_visible():
            logout_control = self.page.get_by_role(
                "link",
                name="Log out",
                exact=True
            )
        expect(logout_control).to_be_visible(timeout=15000)
        logout_control.click()

    def verify_logged_out(self):
        expect(self.page).to_have_url("**/account/signin", timeout=20000)
